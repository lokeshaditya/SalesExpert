import json
import pandas as pd

from db_service import count_total_records, get_average_sales, get_total_sales_by_region, insert_sales_data, setup_database

def load_csv(file_path):
    """Load CSV safely with error handling"""
    try:
        return pd.read_csv(file_path)
    except Exception as e:
        print(f"Error reading {file_path}: {e}")
        return None

def save_csv(df, file_path):
    """Save CSV safely with error handling"""
    try:
        df.to_csv(file_path, index=False)
        print(f"Saved file: {file_path}")
    except Exception as e:
        print(f"Error writing {file_path}: {e}")

def add_region_in_sales_data(csv_file, region):
    df = load_csv(csv_file)
    if df is not None:
        df['region'] = region
        save_csv(df, csv_file)
        print(f"Added 'region' column with value '{region}' in {csv_file}")

def combine_files(file1, file2, output_file="data/sales_master.csv"):
    df1, df2 = load_csv(file1), load_csv(file2)
    if df1 is not None and df2 is not None:
        df = pd.concat([df1, df2], ignore_index=True)
        save_csv(df, output_file)
        print(f"Merged {file1} and {file2} into {output_file}")

def remove_duplicate_orders(inp_file):
    df = load_csv(inp_file)
    if df is not None:
        initial_records = len(df)
        df.drop_duplicates(subset=['OrderId'], keep='first', inplace=True)
        save_csv(df, inp_file)
        print(f"Removed {initial_records - len(df)} duplicate orders from {inp_file}")

def find_total_sales(inp_file):
    df = load_csv(inp_file)
    if df is not None:
        df['total_sales'] = df['QuantityOrdered'] * df['ItemPrice']
        save_csv(df, inp_file)
        print(f"Calculated 'total_sales' in {inp_file}")

def find_net_sales(inp_file):
    df = load_csv(inp_file)
    if df is not None:
        # Handle missing or incorrectly formatted PromotionDiscount
        df['PromotionDiscount'] = df['PromotionDiscount'].fillna('{"Amount": "0"}')

        try:
            df['PromotionDiscount'] = df['PromotionDiscount'].apply(lambda x: json.loads(str(x).replace("'", '"')))
            df['discount'] = df['PromotionDiscount'].apply(lambda x: float(x.get('Amount', 0)))
        except Exception as e:
            print(f"Error processing PromotionDiscount: {e}")
            df['discount'] = 0

        df['net_sales'] = df['total_sales'] - df['discount']
        save_csv(df, inp_file)
        print(f"Calculated 'net_sales' in {inp_file}")

def remove_orders_with_zero_sales(inp_file):
    df = load_csv(inp_file)
    if df is not None:
        initial_records = len(df)
        df = df[df['net_sales'] != 0]
        save_csv(df, inp_file)
        print(f"Removed {initial_records - len(df)} orders with zero net sales from {inp_file}")

def main():
    sales_master_file = "data/sales_master.csv"

    # Add column 'region' in respective sales data
    add_region_in_sales_data("data/order_region_a.csv", "A")
    add_region_in_sales_data("data/order_region_b.csv", "B")

    # Combine both region sales data
    combine_files("data/order_region_a.csv", "data/order_region_b.csv", sales_master_file)

    # Process sales data
    remove_duplicate_orders(sales_master_file)
    find_total_sales(sales_master_file)
    find_net_sales(sales_master_file)
    remove_orders_with_zero_sales(sales_master_file)

    # Connect to Database
    setup_database()
    insert_sales_data("data/sales_master.csv")

    # User Queries
    count_total_records()
    get_total_sales_by_region()
    get_average_sales()


if __name__ == "__main__":
    main()
