import psycopg2
import pandas as pd

DB_CONFIG = {
        "dbname": "SalesMaster",
        "user": "postgres",
        "password": "admin",
        "host": "localhost",
        "port": "5433"
    }


def setup_database():
    conn = psycopg2.connect(**DB_CONFIG)
    cursor = conn.cursor()
    
    # Create table
    create_table_query = """
    CREATE TABLE IF NOT EXISTS public.sales_records (
        order_id VARCHAR(50) PRIMARY KEY,
        order_item_id VARCHAR(50),
        quantity_ordered INT,
        item_price FLOAT,
        batch_id INT,
        region VARCHAR(10),
        total_sales FLOAT,
        discount FLOAT,
        net_sales FLOAT
    );
    """
    
    cursor.execute(create_table_query)
    conn.commit()
    cursor.close()
    conn.close()
    print("Database table created successfully.")


def insert_sales_data(csv_file):
    conn = psycopg2.connect(**DB_CONFIG)
    cursor = conn.cursor()

    # Load CSV into Pandas DataFrame
    df = pd.read_csv(csv_file)

    # Convert PromotionDiscount column to JSON
    df['PromotionDiscount'] = df['PromotionDiscount'].fillna('{}')
    
    # Insert data row by row
    for _, row in df.iterrows():
        cursor.execute("""
            INSERT INTO public.sales_records (
                order_id, order_item_id, quantity_ordered, item_price, 
                batch_id, region, total_sales, discount, net_sales
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s);""", 
            (
            row['OrderId'], row['OrderItemId'], row['QuantityOrdered'], row['ItemPrice'],
            row['batch_id'], row['region'], row['total_sales'],row['discount'], row['net_sales']
        ))
    
    conn.commit()
    cursor.close()
    conn.close()
    print(f"Inserted {len(df)} records into Database.")


def count_total_records():
    conn = psycopg2.connect(**DB_CONFIG)
    cursor = conn.cursor()

    query = "SELECT COUNT(*) FROM public.sales_records;"
    cursor.execute(query)
    count = cursor.fetchone()[0]
    print(f"Total {count} records found")

    
    conn.commit()
    cursor.close()
    conn.close()


def get_total_sales_by_region():
    conn = psycopg2.connect(**DB_CONFIG)
    cursor = conn.cursor()

    query = "SELECT REGION, SUM(TOTAL_SALES) FROM PUBLIC.SALES_RECORDS GROUP BY REGION;"
    cursor.execute(query)
    result = cursor.fetchone()
    print(f"Total sales in region {result[0]} is {result[1]}")

    conn.commit()
    cursor.close()
    conn.close()


def get_average_sales():
    conn = psycopg2.connect(**DB_CONFIG)
    cursor = conn.cursor()

    query = "SELECT AVG(TOTAL_SALES) FROM PUBLIC.SALES_RECORDS;"
    cursor.execute(query)
    print(f"Average sales: {cursor.fetchone()[0]}")

    conn.commit()
    cursor.close()
    conn.close()